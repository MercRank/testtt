gdjs.GameSceneCode = {};
gdjs.GameSceneCode.localVariables = [];
gdjs.GameSceneCode.forEachIndex2 = 0;

gdjs.GameSceneCode.forEachIndex3 = 0;

gdjs.GameSceneCode.forEachObjects2 = [];

gdjs.GameSceneCode.forEachObjects3 = [];

gdjs.GameSceneCode.forEachTemporary2 = null;

gdjs.GameSceneCode.forEachTemporary3 = null;

gdjs.GameSceneCode.forEachTotalCount2 = 0;

gdjs.GameSceneCode.forEachTotalCount3 = 0;

gdjs.GameSceneCode.GDGoldTextObjects1= [];
gdjs.GameSceneCode.GDGoldTextObjects2= [];
gdjs.GameSceneCode.GDGoldTextObjects3= [];
gdjs.GameSceneCode.GDGoldTextObjects4= [];
gdjs.GameSceneCode.GDStoneTextObjects1= [];
gdjs.GameSceneCode.GDStoneTextObjects2= [];
gdjs.GameSceneCode.GDStoneTextObjects3= [];
gdjs.GameSceneCode.GDStoneTextObjects4= [];
gdjs.GameSceneCode.GDWoodTextObjects1= [];
gdjs.GameSceneCode.GDWoodTextObjects2= [];
gdjs.GameSceneCode.GDWoodTextObjects3= [];
gdjs.GameSceneCode.GDWoodTextObjects4= [];
gdjs.GameSceneCode.GDVignetteObjects1= [];
gdjs.GameSceneCode.GDVignetteObjects2= [];
gdjs.GameSceneCode.GDVignetteObjects3= [];
gdjs.GameSceneCode.GDVignetteObjects4= [];
gdjs.GameSceneCode.GDIncomeTextObjects1= [];
gdjs.GameSceneCode.GDIncomeTextObjects2= [];
gdjs.GameSceneCode.GDIncomeTextObjects3= [];
gdjs.GameSceneCode.GDIncomeTextObjects4= [];
gdjs.GameSceneCode.GDHouseButtonObjects1= [];
gdjs.GameSceneCode.GDHouseButtonObjects2= [];
gdjs.GameSceneCode.GDHouseButtonObjects3= [];
gdjs.GameSceneCode.GDHouseButtonObjects4= [];
gdjs.GameSceneCode.GDMineButtonObjects1= [];
gdjs.GameSceneCode.GDMineButtonObjects2= [];
gdjs.GameSceneCode.GDMineButtonObjects3= [];
gdjs.GameSceneCode.GDMineButtonObjects4= [];
gdjs.GameSceneCode.GDLumberButtonObjects1= [];
gdjs.GameSceneCode.GDLumberButtonObjects2= [];
gdjs.GameSceneCode.GDLumberButtonObjects3= [];
gdjs.GameSceneCode.GDLumberButtonObjects4= [];
gdjs.GameSceneCode.GDFloorGridObjects1= [];
gdjs.GameSceneCode.GDFloorGridObjects2= [];
gdjs.GameSceneCode.GDFloorGridObjects3= [];
gdjs.GameSceneCode.GDFloorGridObjects4= [];
gdjs.GameSceneCode.GDHouseObjectObjects1= [];
gdjs.GameSceneCode.GDHouseObjectObjects2= [];
gdjs.GameSceneCode.GDHouseObjectObjects3= [];
gdjs.GameSceneCode.GDHouseObjectObjects4= [];
gdjs.GameSceneCode.GDMineObjectObjects1= [];
gdjs.GameSceneCode.GDMineObjectObjects2= [];
gdjs.GameSceneCode.GDMineObjectObjects3= [];
gdjs.GameSceneCode.GDMineObjectObjects4= [];
gdjs.GameSceneCode.GDLumberObjectObjects1= [];
gdjs.GameSceneCode.GDLumberObjectObjects2= [];
gdjs.GameSceneCode.GDLumberObjectObjects3= [];
gdjs.GameSceneCode.GDLumberObjectObjects4= [];
gdjs.GameSceneCode.GDIndicatorObjectObjects1= [];
gdjs.GameSceneCode.GDIndicatorObjectObjects2= [];
gdjs.GameSceneCode.GDIndicatorObjectObjects3= [];
gdjs.GameSceneCode.GDIndicatorObjectObjects4= [];
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects1= [];
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects2= [];
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects3= [];
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects4= [];
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects1= [];
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects2= [];
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects3= [];
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects4= [];
gdjs.GameSceneCode.GDHexagonForestDetailObjects1= [];
gdjs.GameSceneCode.GDHexagonForestDetailObjects2= [];
gdjs.GameSceneCode.GDHexagonForestDetailObjects3= [];
gdjs.GameSceneCode.GDHexagonForestDetailObjects4= [];
gdjs.GameSceneCode.GDtowerObjects1= [];
gdjs.GameSceneCode.GDtowerObjects2= [];
gdjs.GameSceneCode.GDtowerObjects3= [];
gdjs.GameSceneCode.GDtowerObjects4= [];
gdjs.GameSceneCode.GDForestObjects1= [];
gdjs.GameSceneCode.GDForestObjects2= [];
gdjs.GameSceneCode.GDForestObjects3= [];
gdjs.GameSceneCode.GDForestObjects4= [];
gdjs.GameSceneCode.GDNewTextObjects1= [];
gdjs.GameSceneCode.GDNewTextObjects2= [];
gdjs.GameSceneCode.GDNewTextObjects3= [];
gdjs.GameSceneCode.GDNewTextObjects4= [];
gdjs.GameSceneCode.GDNew3DModelObjects1= [];
gdjs.GameSceneCode.GDNew3DModelObjects2= [];
gdjs.GameSceneCode.GDNew3DModelObjects3= [];
gdjs.GameSceneCode.GDNew3DModelObjects4= [];
gdjs.GameSceneCode.GDNew3DModel2Objects1= [];
gdjs.GameSceneCode.GDNew3DModel2Objects2= [];
gdjs.GameSceneCode.GDNew3DModel2Objects3= [];
gdjs.GameSceneCode.GDNew3DModel2Objects4= [];
gdjs.GameSceneCode.GDtile_9595simpleObjects1= [];
gdjs.GameSceneCode.GDtile_9595simpleObjects2= [];
gdjs.GameSceneCode.GDtile_9595simpleObjects3= [];
gdjs.GameSceneCode.GDtile_9595simpleObjects4= [];
gdjs.GameSceneCode.GDCastleObjects1= [];
gdjs.GameSceneCode.GDCastleObjects2= [];
gdjs.GameSceneCode.GDCastleObjects3= [];
gdjs.GameSceneCode.GDCastleObjects4= [];
gdjs.GameSceneCode.GDtile_9595highObjects1= [];
gdjs.GameSceneCode.GDtile_9595highObjects2= [];
gdjs.GameSceneCode.GDtile_9595highObjects3= [];
gdjs.GameSceneCode.GDtile_9595highObjects4= [];
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects1= [];
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects2= [];
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects3= [];
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects4= [];
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects1= [];
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects2= [];
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects3= [];
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects4= [];


gdjs.GameSceneCode.eventsList0 = function(runtimeScene) {

{



}


{



}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHouseButtonObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDMineButtonObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDLumberButtonObjects2Objects = Hashtable.newFrom({"HouseButton": gdjs.GameSceneCode.GDHouseButtonObjects2, "MineButton": gdjs.GameSceneCode.GDMineButtonObjects2, "LumberButton": gdjs.GameSceneCode.GDLumberButtonObjects2});
gdjs.GameSceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("HouseButton"), gdjs.GameSceneCode.GDHouseButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LumberButton"), gdjs.GameSceneCode.GDLumberButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("MineButton"), gdjs.GameSceneCode.GDMineButtonObjects2);
{gdjs.evtsExt__Toolbar__UpdateToolSelection.func(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHouseButtonObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDMineButtonObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDLumberButtonObjects2Objects, "Effect", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Toolbar__SelectedTool.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "None";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("IndicatorObject"), gdjs.GameSceneCode.GDIndicatorObjectObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorObjectObjects2[i].hide();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Toolbar__SelectedTool.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) != "None";
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("IndicatorObject"), gdjs.GameSceneCode.GDIndicatorObjectObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorObjectObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorObjectObjects1[i].hide(false);
}
}}

}


};gdjs.GameSceneCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableBoolean(runtimeScene.getScene().getVariables().getFromIndex(9), true, false);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(8).setNumber(gdjs.random(10000));
}{runtimeScene.getScene().getVariables().getFromIndex(9).setBoolean(false);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIndicatorObjectObjects2Objects = Hashtable.newFrom({"IndicatorObject": gdjs.GameSceneCode.GDIndicatorObjectObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHouseButtonObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDMineButtonObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDLumberButtonObjects2Objects = Hashtable.newFrom({"HouseButton": gdjs.GameSceneCode.GDHouseButtonObjects2, "MineButton": gdjs.GameSceneCode.GDMineButtonObjects2, "LumberButton": gdjs.GameSceneCode.GDLumberButtonObjects2});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDtowerObjects3Objects = Hashtable.newFrom({"tower": gdjs.GameSceneCode.GDtowerObjects3});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDCastleObjects3Objects = Hashtable.newFrom({"Castle": gdjs.GameSceneCode.GDCastleObjects3});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDLumberObjectObjects2Objects = Hashtable.newFrom({"LumberObject": gdjs.GameSceneCode.GDLumberObjectObjects2});
gdjs.GameSceneCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Toolbar__SelectedTool.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "House";
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDIndicatorObjectObjects2, gdjs.GameSceneCode.GDIndicatorObjectObjects3);

gdjs.copyArray(runtimeScene.getObjects("tile_simple"), gdjs.GameSceneCode.GDtile_9595simpleObjects3);
gdjs.GameSceneCode.GDtowerObjects3.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(3).sub(10);
}{runtimeScene.getScene().getVariables().getFromIndex(4).sub(10);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDtowerObjects3Objects, (( gdjs.GameSceneCode.GDIndicatorObjectObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects3[0].getX()), (( gdjs.GameSceneCode.GDIndicatorObjectObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects3[0].getY()), "");
}{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber((( gdjs.GameSceneCode.GDIndicatorObjectObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects3[0].getX()));
}{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber((( gdjs.GameSceneCode.GDIndicatorObjectObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects3[0].getY()));
}{for(var i = 0, len = gdjs.GameSceneCode.GDtowerObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtowerObjects3[i].getBehavior("Object3D").setZ((( gdjs.GameSceneCode.GDtile_9595simpleObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtile_9595simpleObjects3[0].getDepth()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Toolbar__SelectedTool.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "Mine";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 20;
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameSceneCode.GDIndicatorObjectObjects2, gdjs.GameSceneCode.GDIndicatorObjectObjects3);

gdjs.copyArray(runtimeScene.getObjects("tile_simple"), gdjs.GameSceneCode.GDtile_9595simpleObjects3);
gdjs.GameSceneCode.GDCastleObjects3.length = 0;

{runtimeScene.getScene().getVariables().getFromIndex(2).sub(20);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDCastleObjects3Objects, (( gdjs.GameSceneCode.GDIndicatorObjectObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects3[0].getX()), (( gdjs.GameSceneCode.GDIndicatorObjectObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects3[0].getY()), "");
}{for(var i = 0, len = gdjs.GameSceneCode.GDCastleObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDCastleObjects3[i].getBehavior("Object3D").setZ((( gdjs.GameSceneCode.GDtile_9595simpleObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtile_9595simpleObjects3[0].getDepth()));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Toolbar__SelectedTool.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "Lumber";
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) >= 20;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameSceneCode.GDIndicatorObjectObjects2 */
/* Reuse gdjs.GameSceneCode.GDLumberObjectObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(2).sub(20);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDLumberObjectObjects2Objects, (( gdjs.GameSceneCode.GDIndicatorObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects2[0].getX()), (( gdjs.GameSceneCode.GDIndicatorObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects2[0].getY()), "");
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHouseButtonObjects1ObjectsGDgdjs_9546GameSceneCode_9546GDMineButtonObjects1ObjectsGDgdjs_9546GameSceneCode_9546GDLumberButtonObjects1Objects = Hashtable.newFrom({"HouseButton": gdjs.GameSceneCode.GDHouseButtonObjects1, "MineButton": gdjs.GameSceneCode.GDMineButtonObjects1, "LumberButton": gdjs.GameSceneCode.GDLumberButtonObjects1});
gdjs.GameSceneCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("IndicatorObject"), gdjs.GameSceneCode.GDIndicatorObjectObjects2);
gdjs.copyArray(runtimeScene.getObjects("tile_simple"), gdjs.GameSceneCode.GDtile_9595simpleObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorObjectObjects2[i].setPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0),gdjs.evtTools.input.getCursorY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorObjectObjects2[i].getBehavior("Object3D").setZ((( gdjs.GameSceneCode.GDtile_9595simpleObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDtile_9595simpleObjects2[0].getDepth()) - 19);
}
}{gdjs.evtsExt__HexagonalGrid__SnapObjectToFlatToppedHexagonalGrid.func(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIndicatorObjectObjects2Objects, 120, 104, 60, 52, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("HouseButton"), gdjs.GameSceneCode.GDHouseButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("HouseObject"), gdjs.GameSceneCode.GDHouseObjectObjects2);
gdjs.copyArray(runtimeScene.getObjects("IndicatorObject"), gdjs.GameSceneCode.GDIndicatorObjectObjects2);
gdjs.copyArray(runtimeScene.getObjects("LumberButton"), gdjs.GameSceneCode.GDLumberButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("LumberObject"), gdjs.GameSceneCode.GDLumberObjectObjects2);
gdjs.copyArray(runtimeScene.getObjects("MineButton"), gdjs.GameSceneCode.GDMineButtonObjects2);
gdjs.copyArray(runtimeScene.getObjects("MineObject"), gdjs.GameSceneCode.GDMineObjectObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
isConditionTrue_1 = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHouseButtonObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDMineButtonObjects2ObjectsGDgdjs_9546GameSceneCode_9546GDLumberButtonObjects2Objects, runtimeScene, true, false);
isConditionTrue_0 = !isConditionTrue_1;
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDMineObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDMineObjectObjects2[i].getX() == (( gdjs.GameSceneCode.GDIndicatorObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects2[0].getX()) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDMineObjectObjects2[k] = gdjs.GameSceneCode.GDMineObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDMineObjectObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDLumberObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDLumberObjectObjects2[i].getX() == (( gdjs.GameSceneCode.GDIndicatorObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects2[0].getX()) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDLumberObjectObjects2[k] = gdjs.GameSceneCode.GDLumberObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDLumberObjectObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDHouseObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDHouseObjectObjects2[i].getX() == (( gdjs.GameSceneCode.GDIndicatorObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects2[0].getX()) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDHouseObjectObjects2[k] = gdjs.GameSceneCode.GDHouseObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDHouseObjectObjects2.length = k;
if (isConditionTrue_1) {
isConditionTrue_1 = false;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDMineObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDMineObjectObjects2[i].getY() == (( gdjs.GameSceneCode.GDIndicatorObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects2[0].getY()) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDMineObjectObjects2[k] = gdjs.GameSceneCode.GDMineObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDMineObjectObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDLumberObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDLumberObjectObjects2[i].getY() == (( gdjs.GameSceneCode.GDIndicatorObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects2[0].getY()) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDLumberObjectObjects2[k] = gdjs.GameSceneCode.GDLumberObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDLumberObjectObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameSceneCode.GDHouseObjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDHouseObjectObjects2[i].getY() == (( gdjs.GameSceneCode.GDIndicatorObjectObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDIndicatorObjectObjects2[0].getY()) ) {
        isConditionTrue_1 = true;
        gdjs.GameSceneCode.GDHouseObjectObjects2[k] = gdjs.GameSceneCode.GDHouseObjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDHouseObjectObjects2.length = k;
}
isConditionTrue_0 = !isConditionTrue_1;
}
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("HouseButton"), gdjs.GameSceneCode.GDHouseButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("IndicatorObject"), gdjs.GameSceneCode.GDIndicatorObjectObjects1);
gdjs.copyArray(runtimeScene.getObjects("LumberButton"), gdjs.GameSceneCode.GDLumberButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("MineButton"), gdjs.GameSceneCode.GDMineButtonObjects1);
{gdjs.evtsExt__Toolbar__SetTool.func(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDHouseButtonObjects1ObjectsGDgdjs_9546GameSceneCode_9546GDMineButtonObjects1ObjectsGDgdjs_9546GameSceneCode_9546GDLumberButtonObjects1Objects, "None", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorObjectObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorObjectObjects1[i].hide();
}
}}

}


};gdjs.GameSceneCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("IndicatorObject"), gdjs.GameSceneCode.GDIndicatorObjectObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDIndicatorObjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDIndicatorObjectObjects2[i].hide();
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList2(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Toolbar__SelectedTool.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) != "None";
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfEmptyGDMineObjectObjectsEmptyGDLumberObjectObjectsEmptyGDHouseObjectObjects = Hashtable.newFrom({"MineObject": [], "LumberObject": [], "HouseObject": []});
gdjs.GameSceneCode.mapOfEmptyGDHouseObjectObjects = Hashtable.newFrom({"HouseObject": []});
gdjs.GameSceneCode.mapOfEmptyGDMineObjectObjects = Hashtable.newFrom({"MineObject": []});
gdjs.GameSceneCode.mapOfEmptyGDLumberObjectObjects = Hashtable.newFrom({"LumberObject": []});
gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIncomeTextObjects3Objects = Hashtable.newFrom({"IncomeText": gdjs.GameSceneCode.GDIncomeTextObjects3});
gdjs.GameSceneCode.eventsList6 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIncomeTextObjects3Objects = Hashtable.newFrom({"IncomeText": gdjs.GameSceneCode.GDIncomeTextObjects3});
gdjs.GameSceneCode.eventsList7 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIncomeTextObjects2Objects = Hashtable.newFrom({"IncomeText": gdjs.GameSceneCode.GDIncomeTextObjects2});
gdjs.GameSceneCode.eventsList8 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("HouseObject"), gdjs.GameSceneCode.GDHouseObjectObjects2);

for (gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDHouseObjectObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("GoldText"), gdjs.GameSceneCode.GDGoldTextObjects3);
gdjs.GameSceneCode.GDIncomeTextObjects3.length = 0;

gdjs.GameSceneCode.GDHouseObjectObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDHouseObjectObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDHouseObjectObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIncomeTextObjects3Objects, (( gdjs.GameSceneCode.GDGoldTextObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDGoldTextObjects3[0].getX()) + gdjs.randomFloatInRange(10, 70), (( gdjs.GameSceneCode.GDGoldTextObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDGoldTextObjects3[0].getY()) - gdjs.randomFloatInRange(0, 20), "UI");
}{gdjs.evtTools.firebaseTools.firestore.writeField("Build", "User" + runtimeScene.getScene().getVariables().getFromIndex(8).getAsString(), "Stone", runtimeScene.getScene().getVariables().getFromIndex(3).getAsString(), gdjs.VariablesContainer.badVariable, true);
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("MineObject"), gdjs.GameSceneCode.GDMineObjectObjects2);

for (gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDMineObjectObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("StoneText"), gdjs.GameSceneCode.GDStoneTextObjects3);
gdjs.GameSceneCode.GDIncomeTextObjects3.length = 0;

gdjs.GameSceneCode.GDMineObjectObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDMineObjectObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDMineObjectObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIncomeTextObjects3Objects, (( gdjs.GameSceneCode.GDStoneTextObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDStoneTextObjects3[0].getX()) + gdjs.randomFloatInRange(10, 70), (( gdjs.GameSceneCode.GDStoneTextObjects3.length === 0 ) ? 0 :gdjs.GameSceneCode.GDStoneTextObjects3[0].getY()) - gdjs.randomFloatInRange(0, 20), "UI");
}{gdjs.evtTools.firebaseTools.firestore.writeField("Build", "User" + runtimeScene.getScene().getVariables().getFromIndex(8).getAsString(), "Stone", runtimeScene.getScene().getVariables().getFromIndex(3).getAsString(), gdjs.VariablesContainer.badVariable, true);
}}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("LumberObject"), gdjs.GameSceneCode.GDLumberObjectObjects1);

for (gdjs.GameSceneCode.forEachIndex2 = 0;gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.GDLumberObjectObjects1.length;++gdjs.GameSceneCode.forEachIndex2) {
gdjs.copyArray(runtimeScene.getObjects("WoodText"), gdjs.GameSceneCode.GDWoodTextObjects2);
gdjs.GameSceneCode.GDIncomeTextObjects2.length = 0;

gdjs.GameSceneCode.GDLumberObjectObjects2.length = 0;


gdjs.GameSceneCode.forEachTemporary2 = gdjs.GameSceneCode.GDLumberObjectObjects1[gdjs.GameSceneCode.forEachIndex2];
gdjs.GameSceneCode.GDLumberObjectObjects2.push(gdjs.GameSceneCode.forEachTemporary2);
let isConditionTrue_0 = false;
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_9546GameSceneCode_9546GDIncomeTextObjects2Objects, (( gdjs.GameSceneCode.GDWoodTextObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDWoodTextObjects2[0].getX()) + gdjs.randomFloatInRange(10, 70), (( gdjs.GameSceneCode.GDWoodTextObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDWoodTextObjects2[0].getY()) - gdjs.randomFloatInRange(0, 20), "UI");
}{gdjs.evtTools.firebaseTools.firestore.writeField("Build", "User" + runtimeScene.getScene().getVariables().getFromIndex(8).getAsString(), "Stone", runtimeScene.getScene().getVariables().getFromIndex(3).getAsString(), gdjs.VariablesContainer.badVariable, true);
}}
}

}


};gdjs.GameSceneCode.eventsList10 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList9(runtimeScene);
}


};gdjs.GameSceneCode.eventsList11 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfEmptyGDMineObjectObjectsEmptyGDLumberObjectObjectsEmptyGDHouseObjectObjects) > 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11843180);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Income");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Income") > 1.5;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Income");
}{runtimeScene.getScene().getVariables().getFromIndex(2).add(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfEmptyGDHouseObjectObjects));
}{runtimeScene.getScene().getVariables().getFromIndex(3).add(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfEmptyGDMineObjectObjects));
}{runtimeScene.getScene().getVariables().getFromIndex(4).add(gdjs.evtTools.object.getSceneInstancesCount((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfEmptyGDLumberObjectObjects));
}
{ //Subevents
gdjs.GameSceneCode.eventsList10(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(11850020);
}
}
if (isConditionTrue_0) {
{gdjs.evtsExt__MousePointerLock__RequestPointerLock.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
{gdjs.evtsExt__MousePointerLock__ExitPointerLock.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(gdjs.evtTools.common.clamp(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)) + gdjs.evtsExt__MousePointerLock__MovementY.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) / 5, 15, 89));
}{runtimeScene.getScene().getVariables().getFromIndex(1).add(gdjs.evtsExt__MousePointerLock__MovementX.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) / 5);
}{gdjs.evtsExt__ThirdPersonCamera__LookFromDistanceAtPosition.func(runtimeScene, gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2, gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2, 800, runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber(), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0)), "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.GameSceneCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtsExt__ThirdPersonCamera__LookFromDistanceAtPosition.func(runtimeScene, gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2, gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2, 800, 0, 30, "", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__Toolbar__SelectedTool.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) == "None";
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameSceneCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList14 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GoldText"), gdjs.GameSceneCode.GDGoldTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewText"), gdjs.GameSceneCode.GDNewTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("StoneText"), gdjs.GameSceneCode.GDStoneTextObjects1);
gdjs.copyArray(runtimeScene.getObjects("WoodText"), gdjs.GameSceneCode.GDWoodTextObjects1);
{gdjs.evtsExt__InstantGamesBridge__IGB_initialize.func(runtimeScene, "telegram", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{gdjs.evtsExt__InstantGamesBridge__AuthorizePlayer.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}{for(var i = 0, len = gdjs.GameSceneCode.GDGoldTextObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDGoldTextObjects1[i].getBehavior("Text").setText("Gold: " + runtimeScene.getScene().getVariables().getFromIndex(2).getAsString());
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDStoneTextObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDStoneTextObjects1[i].getBehavior("Text").setText("Stone: " + runtimeScene.getScene().getVariables().getFromIndex(3).getAsString());
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDWoodTextObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDWoodTextObjects1[i].getBehavior("Text").setText("Wood: " + runtimeScene.getScene().getVariables().getFromIndex(4).getAsString());
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDNewTextObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDNewTextObjects1[i].getBehavior("Text").setText(gdjs.evtsExt__InstantGamesBridge__PlayerID.func(runtimeScene, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.eventsList1(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList5(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList11(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList13(runtimeScene);
}


};

gdjs.GameSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameSceneCode.GDGoldTextObjects1.length = 0;
gdjs.GameSceneCode.GDGoldTextObjects2.length = 0;
gdjs.GameSceneCode.GDGoldTextObjects3.length = 0;
gdjs.GameSceneCode.GDGoldTextObjects4.length = 0;
gdjs.GameSceneCode.GDStoneTextObjects1.length = 0;
gdjs.GameSceneCode.GDStoneTextObjects2.length = 0;
gdjs.GameSceneCode.GDStoneTextObjects3.length = 0;
gdjs.GameSceneCode.GDStoneTextObjects4.length = 0;
gdjs.GameSceneCode.GDWoodTextObjects1.length = 0;
gdjs.GameSceneCode.GDWoodTextObjects2.length = 0;
gdjs.GameSceneCode.GDWoodTextObjects3.length = 0;
gdjs.GameSceneCode.GDWoodTextObjects4.length = 0;
gdjs.GameSceneCode.GDVignetteObjects1.length = 0;
gdjs.GameSceneCode.GDVignetteObjects2.length = 0;
gdjs.GameSceneCode.GDVignetteObjects3.length = 0;
gdjs.GameSceneCode.GDVignetteObjects4.length = 0;
gdjs.GameSceneCode.GDIncomeTextObjects1.length = 0;
gdjs.GameSceneCode.GDIncomeTextObjects2.length = 0;
gdjs.GameSceneCode.GDIncomeTextObjects3.length = 0;
gdjs.GameSceneCode.GDIncomeTextObjects4.length = 0;
gdjs.GameSceneCode.GDHouseButtonObjects1.length = 0;
gdjs.GameSceneCode.GDHouseButtonObjects2.length = 0;
gdjs.GameSceneCode.GDHouseButtonObjects3.length = 0;
gdjs.GameSceneCode.GDHouseButtonObjects4.length = 0;
gdjs.GameSceneCode.GDMineButtonObjects1.length = 0;
gdjs.GameSceneCode.GDMineButtonObjects2.length = 0;
gdjs.GameSceneCode.GDMineButtonObjects3.length = 0;
gdjs.GameSceneCode.GDMineButtonObjects4.length = 0;
gdjs.GameSceneCode.GDLumberButtonObjects1.length = 0;
gdjs.GameSceneCode.GDLumberButtonObjects2.length = 0;
gdjs.GameSceneCode.GDLumberButtonObjects3.length = 0;
gdjs.GameSceneCode.GDLumberButtonObjects4.length = 0;
gdjs.GameSceneCode.GDFloorGridObjects1.length = 0;
gdjs.GameSceneCode.GDFloorGridObjects2.length = 0;
gdjs.GameSceneCode.GDFloorGridObjects3.length = 0;
gdjs.GameSceneCode.GDFloorGridObjects4.length = 0;
gdjs.GameSceneCode.GDHouseObjectObjects1.length = 0;
gdjs.GameSceneCode.GDHouseObjectObjects2.length = 0;
gdjs.GameSceneCode.GDHouseObjectObjects3.length = 0;
gdjs.GameSceneCode.GDHouseObjectObjects4.length = 0;
gdjs.GameSceneCode.GDMineObjectObjects1.length = 0;
gdjs.GameSceneCode.GDMineObjectObjects2.length = 0;
gdjs.GameSceneCode.GDMineObjectObjects3.length = 0;
gdjs.GameSceneCode.GDMineObjectObjects4.length = 0;
gdjs.GameSceneCode.GDLumberObjectObjects1.length = 0;
gdjs.GameSceneCode.GDLumberObjectObjects2.length = 0;
gdjs.GameSceneCode.GDLumberObjectObjects3.length = 0;
gdjs.GameSceneCode.GDLumberObjectObjects4.length = 0;
gdjs.GameSceneCode.GDIndicatorObjectObjects1.length = 0;
gdjs.GameSceneCode.GDIndicatorObjectObjects2.length = 0;
gdjs.GameSceneCode.GDIndicatorObjectObjects3.length = 0;
gdjs.GameSceneCode.GDIndicatorObjectObjects4.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects1.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects2.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects3.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects4.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects1.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects2.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects3.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects4.length = 0;
gdjs.GameSceneCode.GDHexagonForestDetailObjects1.length = 0;
gdjs.GameSceneCode.GDHexagonForestDetailObjects2.length = 0;
gdjs.GameSceneCode.GDHexagonForestDetailObjects3.length = 0;
gdjs.GameSceneCode.GDHexagonForestDetailObjects4.length = 0;
gdjs.GameSceneCode.GDtowerObjects1.length = 0;
gdjs.GameSceneCode.GDtowerObjects2.length = 0;
gdjs.GameSceneCode.GDtowerObjects3.length = 0;
gdjs.GameSceneCode.GDtowerObjects4.length = 0;
gdjs.GameSceneCode.GDForestObjects1.length = 0;
gdjs.GameSceneCode.GDForestObjects2.length = 0;
gdjs.GameSceneCode.GDForestObjects3.length = 0;
gdjs.GameSceneCode.GDForestObjects4.length = 0;
gdjs.GameSceneCode.GDNewTextObjects1.length = 0;
gdjs.GameSceneCode.GDNewTextObjects2.length = 0;
gdjs.GameSceneCode.GDNewTextObjects3.length = 0;
gdjs.GameSceneCode.GDNewTextObjects4.length = 0;
gdjs.GameSceneCode.GDNew3DModelObjects1.length = 0;
gdjs.GameSceneCode.GDNew3DModelObjects2.length = 0;
gdjs.GameSceneCode.GDNew3DModelObjects3.length = 0;
gdjs.GameSceneCode.GDNew3DModelObjects4.length = 0;
gdjs.GameSceneCode.GDNew3DModel2Objects1.length = 0;
gdjs.GameSceneCode.GDNew3DModel2Objects2.length = 0;
gdjs.GameSceneCode.GDNew3DModel2Objects3.length = 0;
gdjs.GameSceneCode.GDNew3DModel2Objects4.length = 0;
gdjs.GameSceneCode.GDtile_9595simpleObjects1.length = 0;
gdjs.GameSceneCode.GDtile_9595simpleObjects2.length = 0;
gdjs.GameSceneCode.GDtile_9595simpleObjects3.length = 0;
gdjs.GameSceneCode.GDtile_9595simpleObjects4.length = 0;
gdjs.GameSceneCode.GDCastleObjects1.length = 0;
gdjs.GameSceneCode.GDCastleObjects2.length = 0;
gdjs.GameSceneCode.GDCastleObjects3.length = 0;
gdjs.GameSceneCode.GDCastleObjects4.length = 0;
gdjs.GameSceneCode.GDtile_9595highObjects1.length = 0;
gdjs.GameSceneCode.GDtile_9595highObjects2.length = 0;
gdjs.GameSceneCode.GDtile_9595highObjects3.length = 0;
gdjs.GameSceneCode.GDtile_9595highObjects4.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects1.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects2.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects3.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects4.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects1.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects2.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects3.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects4.length = 0;

gdjs.GameSceneCode.eventsList14(runtimeScene);
gdjs.GameSceneCode.GDGoldTextObjects1.length = 0;
gdjs.GameSceneCode.GDGoldTextObjects2.length = 0;
gdjs.GameSceneCode.GDGoldTextObjects3.length = 0;
gdjs.GameSceneCode.GDGoldTextObjects4.length = 0;
gdjs.GameSceneCode.GDStoneTextObjects1.length = 0;
gdjs.GameSceneCode.GDStoneTextObjects2.length = 0;
gdjs.GameSceneCode.GDStoneTextObjects3.length = 0;
gdjs.GameSceneCode.GDStoneTextObjects4.length = 0;
gdjs.GameSceneCode.GDWoodTextObjects1.length = 0;
gdjs.GameSceneCode.GDWoodTextObjects2.length = 0;
gdjs.GameSceneCode.GDWoodTextObjects3.length = 0;
gdjs.GameSceneCode.GDWoodTextObjects4.length = 0;
gdjs.GameSceneCode.GDVignetteObjects1.length = 0;
gdjs.GameSceneCode.GDVignetteObjects2.length = 0;
gdjs.GameSceneCode.GDVignetteObjects3.length = 0;
gdjs.GameSceneCode.GDVignetteObjects4.length = 0;
gdjs.GameSceneCode.GDIncomeTextObjects1.length = 0;
gdjs.GameSceneCode.GDIncomeTextObjects2.length = 0;
gdjs.GameSceneCode.GDIncomeTextObjects3.length = 0;
gdjs.GameSceneCode.GDIncomeTextObjects4.length = 0;
gdjs.GameSceneCode.GDHouseButtonObjects1.length = 0;
gdjs.GameSceneCode.GDHouseButtonObjects2.length = 0;
gdjs.GameSceneCode.GDHouseButtonObjects3.length = 0;
gdjs.GameSceneCode.GDHouseButtonObjects4.length = 0;
gdjs.GameSceneCode.GDMineButtonObjects1.length = 0;
gdjs.GameSceneCode.GDMineButtonObjects2.length = 0;
gdjs.GameSceneCode.GDMineButtonObjects3.length = 0;
gdjs.GameSceneCode.GDMineButtonObjects4.length = 0;
gdjs.GameSceneCode.GDLumberButtonObjects1.length = 0;
gdjs.GameSceneCode.GDLumberButtonObjects2.length = 0;
gdjs.GameSceneCode.GDLumberButtonObjects3.length = 0;
gdjs.GameSceneCode.GDLumberButtonObjects4.length = 0;
gdjs.GameSceneCode.GDFloorGridObjects1.length = 0;
gdjs.GameSceneCode.GDFloorGridObjects2.length = 0;
gdjs.GameSceneCode.GDFloorGridObjects3.length = 0;
gdjs.GameSceneCode.GDFloorGridObjects4.length = 0;
gdjs.GameSceneCode.GDHouseObjectObjects1.length = 0;
gdjs.GameSceneCode.GDHouseObjectObjects2.length = 0;
gdjs.GameSceneCode.GDHouseObjectObjects3.length = 0;
gdjs.GameSceneCode.GDHouseObjectObjects4.length = 0;
gdjs.GameSceneCode.GDMineObjectObjects1.length = 0;
gdjs.GameSceneCode.GDMineObjectObjects2.length = 0;
gdjs.GameSceneCode.GDMineObjectObjects3.length = 0;
gdjs.GameSceneCode.GDMineObjectObjects4.length = 0;
gdjs.GameSceneCode.GDLumberObjectObjects1.length = 0;
gdjs.GameSceneCode.GDLumberObjectObjects2.length = 0;
gdjs.GameSceneCode.GDLumberObjectObjects3.length = 0;
gdjs.GameSceneCode.GDLumberObjectObjects4.length = 0;
gdjs.GameSceneCode.GDIndicatorObjectObjects1.length = 0;
gdjs.GameSceneCode.GDIndicatorObjectObjects2.length = 0;
gdjs.GameSceneCode.GDIndicatorObjectObjects3.length = 0;
gdjs.GameSceneCode.GDIndicatorObjectObjects4.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects1.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects2.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects3.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadIDetailObjects4.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects1.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects2.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects3.length = 0;
gdjs.GameSceneCode.GDHexagonForestRoadDDetailObjects4.length = 0;
gdjs.GameSceneCode.GDHexagonForestDetailObjects1.length = 0;
gdjs.GameSceneCode.GDHexagonForestDetailObjects2.length = 0;
gdjs.GameSceneCode.GDHexagonForestDetailObjects3.length = 0;
gdjs.GameSceneCode.GDHexagonForestDetailObjects4.length = 0;
gdjs.GameSceneCode.GDtowerObjects1.length = 0;
gdjs.GameSceneCode.GDtowerObjects2.length = 0;
gdjs.GameSceneCode.GDtowerObjects3.length = 0;
gdjs.GameSceneCode.GDtowerObjects4.length = 0;
gdjs.GameSceneCode.GDForestObjects1.length = 0;
gdjs.GameSceneCode.GDForestObjects2.length = 0;
gdjs.GameSceneCode.GDForestObjects3.length = 0;
gdjs.GameSceneCode.GDForestObjects4.length = 0;
gdjs.GameSceneCode.GDNewTextObjects1.length = 0;
gdjs.GameSceneCode.GDNewTextObjects2.length = 0;
gdjs.GameSceneCode.GDNewTextObjects3.length = 0;
gdjs.GameSceneCode.GDNewTextObjects4.length = 0;
gdjs.GameSceneCode.GDNew3DModelObjects1.length = 0;
gdjs.GameSceneCode.GDNew3DModelObjects2.length = 0;
gdjs.GameSceneCode.GDNew3DModelObjects3.length = 0;
gdjs.GameSceneCode.GDNew3DModelObjects4.length = 0;
gdjs.GameSceneCode.GDNew3DModel2Objects1.length = 0;
gdjs.GameSceneCode.GDNew3DModel2Objects2.length = 0;
gdjs.GameSceneCode.GDNew3DModel2Objects3.length = 0;
gdjs.GameSceneCode.GDNew3DModel2Objects4.length = 0;
gdjs.GameSceneCode.GDtile_9595simpleObjects1.length = 0;
gdjs.GameSceneCode.GDtile_9595simpleObjects2.length = 0;
gdjs.GameSceneCode.GDtile_9595simpleObjects3.length = 0;
gdjs.GameSceneCode.GDtile_9595simpleObjects4.length = 0;
gdjs.GameSceneCode.GDCastleObjects1.length = 0;
gdjs.GameSceneCode.GDCastleObjects2.length = 0;
gdjs.GameSceneCode.GDCastleObjects3.length = 0;
gdjs.GameSceneCode.GDCastleObjects4.length = 0;
gdjs.GameSceneCode.GDtile_9595highObjects1.length = 0;
gdjs.GameSceneCode.GDtile_9595highObjects2.length = 0;
gdjs.GameSceneCode.GDtile_9595highObjects3.length = 0;
gdjs.GameSceneCode.GDtile_9595highObjects4.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects1.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects2.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects3.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595curveObjects4.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects1.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects2.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects3.length = 0;
gdjs.GameSceneCode.GDtile_9595road_9595straightObjects4.length = 0;


return;

}

gdjs['GameSceneCode'] = gdjs.GameSceneCode;
